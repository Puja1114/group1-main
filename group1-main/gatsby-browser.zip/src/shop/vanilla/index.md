---
title: Vanilla buttercream with sprinkles
date: 2019-06-19
category: "Pharmacy"
id: 6
price: 340
image: "Pr_6"
description: A delicious vanilla buttercream treat
customField:
  name: Pack Size
  values:
    [
      { name: "One Cake", priceChange: 0 },
      { name: "Pack of 6", priceChange: 14.00 },
      { name: "Pack of 12", priceChange: 28.50 },
    ]
---

This is a very yummy cake.
