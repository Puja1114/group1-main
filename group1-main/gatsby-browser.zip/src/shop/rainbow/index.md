---
title: Rainbow buttercream
date: 2019-06-19
category: "Pharmacy"
id: 5
price: 2
image: "Pr_5"
description: A vanilla cake with rainbow buttercream icing.
customField:
  name: Pack Size
  values:
    [
      { name: "One Cake", priceChange: 0 },
      { name: "Pack of 6", priceChange: 9.50 },
      { name: "Pack of 12", priceChange: 20.00 },
    ]
---

This cake will match your pet unicorn nicely.
