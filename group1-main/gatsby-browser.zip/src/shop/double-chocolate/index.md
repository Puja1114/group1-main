---
title: Double chocolate buttercream
date: 2019-06-19
category: "Grocery"
id: 2
price: 300
image: "Pr_2"
description: A delicious chocolatey treat.
customField:
  name: Quantity
  values:
    [
      { name: "1", priceChange: 0 },
      { name: "2", priceChange: 300 },
      { name: "3", priceChange: 600 },
    ]
---

This is a yummy cake.
