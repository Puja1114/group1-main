---
title: Chocolate and pretzel cupcakes
date: 2019-06-19
category: "Pharmacy"
id: 4
price: 350
image: "Pr_4"
description: A delicious pretzel topped treat
customField:
  name: Pack Size
  values:
    [
      { name: "One Cake", priceChange: 0 },
      { name: "Pack of 6", priceChange: -1.00 },
      { name: "Pack of 12", priceChange: 28.50 },
    ]
---

This is a very yummy cake topped with a pretzel.
