---
title: Halloween cake
date: 2019-06-19
category: "Pharmacy"
id: 3
price: 250
image: "Pr_9"
description: A scary but tasty treat.
customField:
  name: Quantity
  values:
    [
      { name: "1", priceChange: 0 },
      { name: "2", priceChange: 300 },
      { name: "3", priceChange: 600 },
    ]
---

This is a very scary cake.
