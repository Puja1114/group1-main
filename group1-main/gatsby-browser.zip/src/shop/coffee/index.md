---
title: Coffee Buttercream
date: 2019-06-19
category: "Grocery"
id: 1
price: 300
image: "Pr_1"
description: A delicious coffee flavoured treat.
customField:
  name: Quantity
  values:
    [
      { name: "1", priceChange: 0 },
      { name: "2", priceChange: 300 },
      { name: "3", priceChange: 600 },
    ]
---

This is a yummy cake with coffee buttercream icing.
